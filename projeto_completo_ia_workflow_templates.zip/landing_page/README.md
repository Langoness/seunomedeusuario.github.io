# README.md - IA Workflow Templates

## Sobre o Projeto

IA Workflow Templates é uma plataforma que oferece modelos pré-configurados com IA para otimizar fluxos de trabalho profissionais. Nossa missão é ajudar profissionais e empresas a economizarem tempo em tarefas repetitivas através de templates inteligentes e prontos para usar.

## Características Principais

- Templates de IA para diversos casos de uso profissionais
- Sem necessidade de conhecimento técnico para implementação
- Resultados imediatos e economia de tempo comprovada
- Personalização fácil para diferentes necessidades
- Integração com ferramentas populares de produtividade

## Estrutura do Repositório

Este repositório contém a landing page do projeto IA Workflow Templates:

- `index.html` - Página principal com informações sobre os templates e planos
- `questionario.html` - Formulário para coletar feedback dos usuários
- `obrigado.html` - Página de agradecimento após submissão do formulário

## Como Contribuir

1. Faça um fork deste repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## Contato

Para mais informações, entre em contato através do formulário em nossa landing page ou envie um email para contato@iaworkflowtemplates.com.

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para mais detalhes.
