# Questionário de Feedback - IA Workflow Templates

## Objetivo
Este questionário visa coletar feedback qualitativo sobre nossos templates de IA para produtividade, ajudando-nos a entender melhor as necessidades dos usuários e aprimorar nossa oferta.

## Perguntas

### 1. Qual sua principal área de atuação profissional?
- [ ] Marketing e Comunicação
- [ ] Tecnologia e Desenvolvimento
- [ ] Gestão de Projetos
- [ ] Criação de Conteúdo
- [ ] Vendas
- [ ] Recursos Humanos
- [ ] Educação
- [ ] Outro: _________________

### 2. Quais tarefas repetitivas consomem mais do seu tempo atualmente?
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

### 3. Qual dos templates apresentados seria mais útil para você?
- [ ] Blog Post Generator
- [ ] Smart Project Planner
- [ ] Customer Feedback Analyzer
- [ ] Outro: _________________

### 4. Por que este template específico chamou sua atenção?
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

### 5. Quanto tempo você estima que poderia economizar semanalmente com esses templates?
- [ ] Menos de 2 horas
- [ ] 2-5 horas
- [ ] 6-10 horas
- [ ] Mais de 10 horas

### 6. Qual valor você consideraria justo pagar mensalmente por uma solução como esta?
- [ ] Apenas versão gratuita
- [ ] R$ 19-29
- [ ] R$ 30-49
- [ ] R$ 50-99
- [ ] R$ 100 ou mais

### 7. Quais outras ferramentas de produtividade você utiliza atualmente?
_____________________________________________________________________
_____________________________________________________________________

### 8. Que outros templates você gostaria de ver disponíveis?
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

### 9. Qual é o seu maior desafio em termos de produtividade atualmente?
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

### 10. Como você preferiria receber atualizações sobre novos templates e recursos?
- [ ] Email
- [ ] Newsletter
- [ ] Redes sociais
- [ ] Notificações no aplicativo
- [ ] Outro: _________________

## Agradecimento
Muito obrigado por dedicar seu tempo para responder este questionário! Seu feedback é extremamente valioso para nós e nos ajudará a criar templates que realmente atendam às suas necessidades.

Como agradecimento, gostaríamos de oferecer acesso antecipado aos nossos próximos lançamentos. Por favor, deixe seu email abaixo se tiver interesse:

Email: _____________________________
